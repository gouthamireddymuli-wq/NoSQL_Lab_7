"""
Entry point – run with:
    python run.py
or:
    C:\\Users\\gouth\\AppData\\Local\\Programs\\Python\\Python313\\python.exe run.py
"""
from app import app

if __name__ == "__main__":
    app.run(debug=True, port=5000)
